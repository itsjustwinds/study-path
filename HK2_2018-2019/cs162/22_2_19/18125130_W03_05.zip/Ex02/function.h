/*
 * function.h
 *
 *  Created on: Feb 22, 2019
 *      Author: huy
 */
#pragma once
#ifndef FUNCTION_H_
#define FUNCTION_H_

#include<iostream>
using namespace std;
int dosomething(int *a,int *b);



#endif /* FUNCTION_H_ */
