/*
 * addOne.cpp
 *
 *  Created on: Feb 22, 2019
 *      Author: huy
 */

#include"addOne.h"
void addOne(int *ptrNum){
	*ptrNum+=1;
}


