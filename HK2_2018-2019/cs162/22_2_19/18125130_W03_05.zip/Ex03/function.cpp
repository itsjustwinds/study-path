/*
 * function.cpp
 *
 *  Created on: Feb 28, 2019
 *      Author: huy
 */

#include"function.h"
void input(int &n,int *&a){
	cin>>n;
	a=new int[n];
	for (int i=0;i<n;++i)
		cin>>a[i];
}

int greatest_frequency(int &n,int *&a){
	int res,cnt=0;
	for (int i=0;i<n;++i){
		int appear=0;
		for (int j=i;j<n;++j)
			if (a[i]==a[j]) ++appear;
		if (appear>cnt){
			cnt=appear;
			res=a[i];
		}
	}
	if (cnt<=1) return -1;
	return res;
}
