/*
 * 18125130_Ex01.cpp
 *
 *  Created on: Mar 29, 2019
 *      Author: huy
 */
#include"function.h"

int main(){
	init();
}


