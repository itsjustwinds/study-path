/*
 * main.cpp
 *
 *  Created on: Feb 22, 2019
 *      Author: huy
 */

#include"function.h"
int main(){
	int x=10,y=100;
	int *a,*b;
	a=&x;
	b=&y;
	cout<<dosomething(a,b);
	return 0;
}


