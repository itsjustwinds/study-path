/*
 * main.cpp
 *
 *  Created on: Mar 28, 2019
 *      Author: huy
 */

#include"function.h"
int main(){
	init_array(6);
}


