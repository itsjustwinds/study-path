/*
 * function.h
 *
 *  Created on: Mar 22, 2019
 *      Author: huy
 */

#ifndef FUNCTION_H_
#define FUNCTION_H_
#include"fstream"
#include<cstring>
#include<iostream>

using namespace std;
bool isPalindrome(int l, int r, char* s);
void input(ifstream &fin,char *&s);

#endif /* FUNCTION_H_ */
