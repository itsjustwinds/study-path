/*
 * function.h
 *
 *  Created on: Feb 28, 2019
 *      Author: huy
 */

#ifndef FUNCTION_H_
#define FUNCTION_H_

#include<cstring>
#include<iostream>
using namespace std;
bool isPalindrome(char *cstr);



#endif /* FUNCTION_H_ */
