/*
 * main.cpp
 *
 *  Created on: Mar 28, 2019
 *      Author: huy
 */

#include"function.h"

int main(){
	Move(4,'A','C','B');
}

