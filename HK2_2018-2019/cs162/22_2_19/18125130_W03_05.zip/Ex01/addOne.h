/*
 * addOne.h
 *
 *  Created on: Feb 22, 2019
 *      Author: huy
 */
#pragma once
#ifndef ADDONE_H_
#define ADDONE_H_

#include<iostream>
using namespace std;
void addOne(int *ptrN);

#endif /* ADDONE_H_ */
