/*
 * main.cpp
 *
 *  Created on: Mar 28, 2019
 *      Author: huy
 */

#include"function.h"
int main(){
	cout<<sum_of_ditgits(1236);
}


