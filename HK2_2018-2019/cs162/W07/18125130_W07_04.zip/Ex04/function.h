/*
 * function.h
 *
 *  Created on: Mar 28, 2019
 *      Author: huy
 */

#ifndef FUNCTION_H_
#define FUNCTION_H_
#include<iostream>
using namespace std;

void Move(int n, char A, char C, char B);


#endif /* FUNCTION_H_ */
