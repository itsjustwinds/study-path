/*
 * book_store.h
 *
 *  Created on: Mar 14, 2019
 *      Author: huy
 */
#pragma once
#ifndef BOOK_STORE_H_
#define BOOK_STORE_H_
#include"book.h"
struct book_store{
	book *item;
	void init();
	bool input(book *New);
	bool sell(book *New);
	void find(char s[]);
	void remove_less_than_k(int k);
	void delete_all(book *&item);
};



#endif /* BOOK_STORE_H_ */
