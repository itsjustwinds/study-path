/*
 * function.h
 *
 *  Created on: Mar 29, 2019
 *      Author: huy
 */

#ifndef FUNCTION_H_
#define FUNCTION_H_
#include<iostream>
using namespace std;
void back_track(int stage,int *&resX,int *&resY,int *&row,int *&col,int *&fDia,int *&sDia,int &ok);
void init();



#endif /* FUNCTION_H_ */
